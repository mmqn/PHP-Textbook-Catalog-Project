<!DOCTYPE html>
<html>
    <head>
        <title>CIS Book Catalog</title>
        <link rel="stylesheet" type="text/css" href="main.css">
    </head>

    <body>
    <main>
        <h3><i>CIS Department Book Catalog</i></h3>
        <h1><b>Database Error</b></h1>
        <p>Database Connection: Failed.</p>
        <p>Error Message: <?php echo $error_msg; ?></p>
    </main>
    </body>
</html>
